//
//  Header.h
//  fish
//
//  Created by andy on 15/3/16.
//
//

#ifndef fish_Common_h
#define fish_Common_h
#include "cocos2d.h"
#include "ToolsOper.h"
//#define PUBLISH_GOVERNMENT    //
#define PUBLISH_OFFLINE       //
#define PUBLISH_TEST
#endif
