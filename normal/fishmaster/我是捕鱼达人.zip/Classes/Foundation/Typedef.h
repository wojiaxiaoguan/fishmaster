//
//  typedef.h
//  fish
//
//  Created by lezeng on 13-12-3.
//
//

#ifndef fish_typedef_h
#define fish_typedef_h

#define TUint8 unsigned char
//#define Byte TUint8

#define TInt8  char

#define TUint32 unsigned int

#define TInt32 int


#endif
